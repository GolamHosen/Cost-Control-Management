import {
  pgTable,
  serial,
  integer,
  text,
  numeric,
  timestamp,
  unique,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";

// ----------------------------------------------------------------------------
// Projects — a construction job / build
// ----------------------------------------------------------------------------
export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  client: text("client"),
  location: text("location"),
  budget: numeric("budget", { precision: 16, scale: 2 }),
  startDate: text("start_date"),
  status: text("status").notNull().default("Active"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

// ----------------------------------------------------------------------------
// Sheets — each project has two predefined (but fully editable) sheets
// ----------------------------------------------------------------------------
export const sheets = pgTable("sheets", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id")
    .notNull()
    .references(() => projects.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  // 'expense' | 'cost_control'
  type: text("type").notNull(),
  position: integer("position").notNull().default(0),
});

// ----------------------------------------------------------------------------
// Columns — DYNAMIC headers. Add / delete / rename / retype at will.
// ----------------------------------------------------------------------------
export const columns = pgTable("columns", {
  id: serial("id").primaryKey(),
  sheetId: integer("sheet_id")
    .notNull()
    .references(() => sheets.id, { onDelete: "cascade" }),
  label: text("label").notNull(),
  // 'text' | 'number' | 'currency' | 'date' | 'select'
  type: text("type").notNull().default("text"),
  options: text("options").array(),
  // role used by the reconciliation engine to cross-check the two sheets
  // 'expense_amount' | 'cost_budget' | 'cost_actual' | 'cost_paid' | 'reconcile_key'
  reconcileRole: text("reconcile_role"),
  width: integer("width").notNull().default(180),
  position: integer("position").notNull().default(0),
});

// ----------------------------------------------------------------------------
// Rows + Cells — Excel-like grid data
// ----------------------------------------------------------------------------
export const rows = pgTable("rows", {
  id: serial("id").primaryKey(),
  sheetId: integer("sheet_id")
    .notNull()
    .references(() => sheets.id, { onDelete: "cascade" }),
  position: integer("position").notNull().default(0),
});

export const cells = pgTable(
  "cells",
  {
    id: serial("id").primaryKey(),
    rowId: integer("row_id")
      .notNull()
      .references(() => rows.id, { onDelete: "cascade" }),
    columnId: integer("column_id")
      .notNull()
      .references(() => columns.id, { onDelete: "cascade" }),
    value: text("value"),
  },
  (t) => ({
    rowColUnq: unique("cells_row_column_unique").on(t.rowId, t.columnId),
  }),
);

// ----------------------------------------------------------------------------
// Relations — enable db.query.* relational API
// ----------------------------------------------------------------------------
export const projectsRelations = relations(projects, ({ many }) => ({
  sheets: many(sheets),
}));

export const sheetsRelations = relations(sheets, ({ one, many }) => ({
  project: one(projects, { fields: [sheets.projectId], references: [projects.id] }),
  columns: many(columns),
  rows: many(rows),
}));

export const columnsRelations = relations(columns, ({ one }) => ({
  sheet: one(sheets, { fields: [columns.sheetId], references: [sheets.id] }),
}));

export const rowsRelations = relations(rows, ({ one, many }) => ({
  sheet: one(sheets, { fields: [rows.sheetId], references: [sheets.id] }),
  cells: many(cells),
}));

export const cellsRelations = relations(cells, ({ one }) => ({
  row: one(rows, { fields: [cells.rowId], references: [rows.id] }),
  column: one(columns, { fields: [cells.columnId], references: [columns.id] }),
}));
