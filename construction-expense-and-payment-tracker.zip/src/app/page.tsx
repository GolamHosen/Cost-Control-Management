import { listProjects } from "@/lib/queries";
import HomeClient from "@/components/HomeClient";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const projects = await listProjects();
  return <HomeClient projects={projects} />;
}
