import { NextRequest } from "next/server";
import { db } from "@/db";
import { projects } from "@/db/schema";
import { seedDefaultSheets } from "@/lib/defaults";

export const dynamic = "force-dynamic";

// Create a project and seed it with the two default cross-checkable sheets.
export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const name = (body.name ?? "").toString().trim() || "Untitled Project";
  const client = body.client ? String(body.client).trim() : null;
  const location = body.location ? String(body.location).trim() : null;
  const budget = body.budget ? String(body.budget) : null;
  const startDate = body.startDate ? String(body.startDate) : null;
  const status = body.status ? String(body.status) : "Active";
  const withSample = body.withSample !== false;

  const [project] = await db
    .insert(projects)
    .values({ name, client, location, budget, startDate, status })
    .returning();

  await seedDefaultSheets(db, project.id, withSample);

  return Response.json({ id: project.id }, { status: 201 });
}
