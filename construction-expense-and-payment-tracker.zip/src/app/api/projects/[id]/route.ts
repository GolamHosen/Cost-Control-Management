import { NextRequest } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { projects } from "@/db/schema";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export async function DELETE(_req: NextRequest, { params }: Ctx) {
  const { id } = await params;
  await db.delete(projects).where(eq(projects.id, Number(id)));
  return Response.json({ ok: true });
}

export async function PATCH(req: NextRequest, { params }: Ctx) {
  const { id } = await params;
  const body = await req.json().catch(() => ({}));
  const patch: Record<string, unknown> = {};

  for (const key of ["name", "client", "location", "startDate", "status"]) {
    if (key in body) patch[key] = body[key] === undefined ? null : body[key];
  }
  if ("budget" in body) patch.budget = body.budget ? String(body.budget) : null;

  if (Object.keys(patch).length === 0) {
    return Response.json({ ok: true });
  }

  await db.update(projects).set(patch).where(eq(projects.id, Number(id)));
  return Response.json({ ok: true });
}
