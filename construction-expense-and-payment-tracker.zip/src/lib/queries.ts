import { asc, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { columns, projects, rows, sheets } from "@/db/schema";
import type { Column, Project, Sheet, SheetRow } from "./types";

async function rawList() {
  return db.query.projects.findMany({
    with: {
      sheets: {
        orderBy: [asc(sheets.position)],
        with: {
          columns: { orderBy: [asc(columns.position)] },
          rows: {
            orderBy: [asc(rows.position)],
            with: { cells: true },
          },
        },
      },
    },
    orderBy: [desc(projects.createdAt)],
  });
}

type RawProject = Awaited<ReturnType<typeof rawList>>[number];

function mapColumn(c: RawProject["sheets"][number]["columns"][number]): Column {
  return {
    id: c.id,
    sheetId: c.sheetId,
    label: c.label,
    type: c.type as Column["type"],
    options: c.options ?? null,
    reconcileRole: (c.reconcileRole ?? null) as Column["reconcileRole"],
    width: c.width,
    position: c.position,
  };
}

function mapSheet(s: RawProject["sheets"][number]): Sheet {
  return {
    id: s.id,
    projectId: s.projectId,
    name: s.name,
    type: s.type as Sheet["type"],
    position: s.position,
    columns: s.columns.map(mapColumn),
    rows: s.rows
      .slice()
      .sort((a, b) => a.position - b.position)
      .map((r): SheetRow => {
        const cellMap: Record<number, string> = {};
        for (const cell of r.cells) cellMap[cell.columnId] = cell.value ?? "";
        return { id: r.id, position: r.position, cells: cellMap };
      }),
  };
}

function mapProject(p: RawProject): Project {
  return {
    id: p.id,
    name: p.name,
    client: p.client,
    location: p.location,
    budget: p.budget,
    startDate: p.startDate,
    status: p.status,
    createdAt: p.createdAt ? String(p.createdAt) : "",
    sheets: p.sheets.slice().sort((a, b) => a.position - b.position).map(mapSheet),
  };
}

export async function listProjects(): Promise<Project[]> {
  return (await rawList()).map(mapProject);
}

export async function getProject(id: number): Promise<Project | null> {
  const p = await db.query.projects.findFirst({
    where: eq(projects.id, id),
    with: {
      sheets: {
        orderBy: [asc(sheets.position)],
        with: {
          columns: { orderBy: [asc(columns.position)] },
          rows: {
            orderBy: [asc(rows.position)],
            with: { cells: true },
          },
        },
      },
    },
  });
  return p ? mapProject(p) : null;
}
