"use client";

import { useEffect, useRef, useState } from "react";
import type { Column, Sheet, SheetRow, SheetType } from "@/lib/types";
import { COLUMN_TYPES, RECONCILE_ROLES } from "@/lib/types";
import { formatCurrency, formatNumber, parseNumber } from "@/lib/finance";
import { ChevronLeft, ChevronRight, Menu, Plus, Trash, X } from "./Icons";

interface Props {
  sheet: Sheet;
  onChangeCell: (rowId: number, columnId: number, value: string) => void;
  onAddRow: () => void;
  onDeleteRow: (rowId: number) => void;
  onAddColumn: () => void;
  onUpdateColumn: (colId: number, patch: Partial<Column>) => void;
  onDeleteColumn: (colId: number) => void;
  onMoveColumn: (colId: number, direction: -1 | 1) => void;
}

function formatDate(v: string): string {
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(v);
  return m ? `${m[3]}/${m[2]}/${m[1]}` : v;
}

function displayValue(col: Column, value: string): string {
  if (value === undefined || value === null || value === "") return "";
  if (col.type === "currency") return formatCurrency(parseNumber(value));
  if (col.type === "number") return formatNumber(parseNumber(value));
  if (col.type === "date") return formatDate(value);
  return value;
}

const ROLE_COLOR: Record<string, string> = {
  expense_amount: "bg-sky-500",
  cost_actual: "bg-violet-500",
  cost_budget: "bg-amber-500",
  cost_paid: "bg-emerald-500",
  reconcile_key: "bg-slate-700",
};

export default function Spreadsheet({
  sheet,
  onChangeCell,
  onAddRow,
  onDeleteRow,
  onAddColumn,
  onUpdateColumn,
  onDeleteColumn,
  onMoveColumn,
}: Props) {
  const cols = sheet.columns;
  const rows = sheet.rows;
  const [selected, setSelected] = useState<{ r: number; c: number } | null>(null);
  const [draft, setDraft] = useState("");
  const activeInput = useRef<HTMLElement | null>(null);

  const cellValue = (r: number, c: number) => rows[r]?.cells[cols[c]?.id] ?? "";

  useEffect(() => {
    const el = activeInput.current;
    if (el) {
      el.focus();
      if (el instanceof HTMLInputElement && el.type === "text") el.select();
    }
  }, [selected]);

  function commit() {
    if (!selected) return;
    const row = rows[selected.r];
    const col = cols[selected.c];
    if (!row || !col) return;
    if (cellValue(selected.r, selected.c) !== draft) {
      onChangeCell(row.id, col.id, draft);
    }
  }

  function beginEdit(r: number, c: number) {
    setSelected({ r, c });
    setDraft(cellValue(r, c));
  }

  function move(dr: number, dc: number) {
    if (!selected) return;
    const r = Math.min(Math.max(selected.r + dr, 0), rows.length - 1);
    const c = Math.min(Math.max(selected.c + dc, 0), cols.length - 1);
    setSelected({ r, c });
    setDraft(cellValue(r, c));
  }

  function handleSelect(r: number, c: number) {
    commit();
    beginEdit(r, c);
  }

  function onInputKeyDown(e: React.KeyboardEvent) {
    if (e.key === "Enter") {
      e.preventDefault();
      commit();
      move(e.shiftKey ? -1 : 1, 0);
    } else if (e.key === "Tab") {
      e.preventDefault();
      commit();
      move(0, e.shiftKey ? -1 : 1);
    } else if (e.key === "Escape") {
      e.preventDefault();
      setDraft(cellValue(selected!.r, selected!.c));
      setSelected(null);
    }
  }

  function onCommitImmediate(value: string) {
    if (!selected) return;
    setDraft(value);
    const row = rows[selected.r];
    const col = cols[selected.c];
    if (row && col && cellValue(selected.r, selected.c) !== value) {
      onChangeCell(row.id, col.id, value);
    }
  }

  const totals: (number | null)[] = cols.map((col) => {
    if (col.type !== "currency" && col.type !== "number") return null;
    return rows.reduce((acc, r) => acc + parseNumber(r.cells[col.id]), 0);
  });

  function renderCell(col: Column, r: number, c: number) {
    const isSel = selected && selected.r === r && selected.c === c;
    const value = cellValue(r, c);
    const numeric = col.type === "currency" || col.type === "number";

    if (isSel) {
      const common = {
        ref: (el: HTMLElement | null) => {
          activeInput.current = el;
        },
        value: draft,
        onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) =>
          setDraft(e.target.value),
        onBlur: commit,
        onKeyDown: onInputKeyDown,
        className:
          "w-full h-full bg-white px-2 py-1.5 outline-none ring-2 ring-amber-500 text-sm",
      };

      if (col.type === "select") {
        return (
          <select {...common} className={common.className + " rounded-none"}>
            <option value="">—</option>
            {(col.options ?? []).map((o) => (
              <option key={o} value={o}>
                {o}
              </option>
            ))}
          </select>
        );
      }
      if (col.type === "date") {
        return <input {...common} type="date" />;
      }
      return (
        <input
          {...common}
          type="text"
          inputMode={numeric ? "decimal" : "text"}
          className={common.className + (numeric ? " text-right" : "")}
        />
      );
    }

    return (
      <button
        type="button"
        onMouseDown={(e) => {
          e.preventDefault();
          handleSelect(r, c);
        }}
        className={`block h-full w-full px-2 py-1.5 text-left text-sm ${
          numeric ? "text-right tabular-nums" : ""
        } ${col.type === "currency" ? "text-slate-900 font-medium" : "text-slate-700"}`}
      >
        {displayValue(col, value) || <span className="text-slate-300">·</span>}
      </button>
    );
  }

  return (
    <div className="flex h-full flex-col">
      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-200 bg-slate-50 px-4 py-2">
        <span className="text-sm font-semibold text-slate-700">{sheet.name}</span>
        <span className="rounded-full bg-slate-200 px-2 py-0.5 text-[11px] font-medium uppercase tracking-wide text-slate-600">
          {sheet.type === "expense" ? "Expense ledger" : "Cost & payments"}
        </span>
        <div className="ml-auto flex items-center gap-2">
          <button
            onClick={onAddColumn}
            className="inline-flex items-center gap-1 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-sm font-medium text-slate-700 hover:bg-slate-100"
          >
            <Plus width={14} /> Column
          </button>
          <button
            onClick={onAddRow}
            className="inline-flex items-center gap-1 rounded-lg bg-slate-900 px-3 py-1.5 text-sm font-medium text-white hover:bg-slate-800"
          >
            <Plus width={14} /> Row
          </button>
        </div>
      </div>

      {/* Grid */}
      <div className="flex-1 overflow-auto">
        <table className="border-collapse table-fixed" style={{ minWidth: "100%" }}>
          <colgroup>
            <col style={{ width: 46 }} />
            {cols.map((c) => (
              <col key={c.id} style={{ width: c.width }} />
            ))}
            <col style={{ width: 80 }} />
          </colgroup>
          <thead>
            <tr>
              <th className="sticky left-0 top-0 z-30 border-b border-r border-slate-300 bg-slate-200/90" />
              {cols.map((col, c) => (
                <ColumnHeader
                  key={col.id}
                  col={col}
                  index={c}
                  count={cols.length}
                  sheetType={sheet.type}
                  onUpdate={(patch) => onUpdateColumn(col.id, patch)}
                  onDelete={() => onDeleteColumn(col.id)}
                  onMove={(dir) => onMoveColumn(col.id, dir)}
                />
              ))}
              <th className="sticky top-0 z-20 border-b border-slate-300 bg-slate-100" />
            </tr>
          </thead>
          <tbody>
            {rows.map((row, r) => (
              <tr key={row.id} className="group">
                <td className="sticky left-0 z-10 border-b border-r border-slate-200 bg-slate-50 px-1 text-center align-middle">
                  <div className="flex items-center justify-center">
                    <span className="text-[11px] text-slate-400 group-hover:invisible">
                      {r + 1}
                    </span>
                    <button
                      onClick={() => onDeleteRow(row.id)}
                      className="absolute text-slate-400 opacity-0 hover:text-red-600 group-hover:opacity-100"
                      title="Delete row"
                    >
                      <Trash width={13} />
                    </button>
                  </div>
                </td>
                {cols.map((col, c) => {
                  const isSel = selected && selected.r === r && selected.c === c;
                  return (
                    <td
                      key={col.id}
                      className={`border-b border-r border-slate-200 p-0 align-middle ${
                        r % 2 ? "bg-slate-50/60" : "bg-white"
                      } ${isSel ? "p-0" : ""}`}
                      style={{ height: 38 }}
                    >
                      {renderCell(col, r, c)}
                    </td>
                  );
                })}
                <td className="border-b border-slate-200 bg-slate-50/60" />
              </tr>
            ))}
            {rows.length === 0 && (
              <tr>
                <td colSpan={cols.length + 2} className="border-b border-slate-200 py-10 text-center text-sm text-slate-400">
                  No rows yet — click “Row” to start entering data.
                </td>
              </tr>
            )}
          </tbody>
          <tfoot>
            <tr className="bg-slate-900 text-white">
              <td className="sticky left-0 z-10 border-r border-slate-700 bg-slate-900 px-2 text-right text-[11px] font-semibold uppercase tracking-wide">
                Σ {rows.length}
              </td>
              {cols.map((col, c) => (
                <td
                  key={col.id}
                  className={`sticky bottom-0 border-r border-slate-700 bg-slate-900 px-2 py-2 text-sm tabular-nums ${
                    totals[c] === null ? "" : "text-right font-semibold"
                  }`}
                >
                  {totals[c] === null
                    ? ""
                    : col.type === "currency"
                      ? formatCurrency(totals[c]!)
                      : formatNumber(totals[c]!)}
                </td>
              ))}
              <td className="bg-slate-900" />
            </tr>
          </tfoot>
        </table>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Column header with rename + dynamic type / role / options menu
// ---------------------------------------------------------------------------
function ColumnHeader({
  col,
  index,
  count,
  sheetType,
  onUpdate,
  onDelete,
  onMove,
}: {
  col: Column;
  index: number;
  count: number;
  sheetType: SheetType;
  onUpdate: (patch: Partial<Column>) => void;
  onDelete: () => void;
  onMove: (dir: -1 | 1) => void;
}) {
  const [menu, setMenu] = useState(false);
  const [rename, setRename] = useState(false);
  const [label, setLabel] = useState(col.label);
  const [optionsDraft, setOptionsDraft] = useState((col.options ?? []).join(", "));
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!menu) return;
    const close = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) setMenu(false);
    };
    document.addEventListener("mousedown", close);
    return () => document.removeEventListener("mousedown", close);
  }, [menu]);

  function commitLabel() {
    setRename(false);
    const v = label.trim();
    if (v && v !== col.label) onUpdate({ label: v });
    else setLabel(col.label);
  }

  return (
    <th
      className={`group sticky top-0 z-20 border-b border-r border-slate-300 px-2 py-1.5 text-left align-top ${
        col.type === "currency" ? "bg-slate-100" : "bg-slate-100"
      }`}
    >
      <div className="flex items-start gap-1">
        <span
          className={`mt-0.5 inline-flex h-4 min-w-4 items-center justify-center rounded bg-slate-200 px-1 text-[10px] font-bold uppercase text-slate-600 ${
            col.type === "currency" ? "!bg-amber-100 !text-amber-700" : ""
          }`}
        >
          {COLUMN_TYPES.find((t) => t.value === col.type)?.icon ?? "T"}
        </span>
        <div className="min-w-0 flex-1">
          {rename ? (
            <input
              autoFocus
              value={label}
              onChange={(e) => setLabel(e.target.value)}
              onBlur={commitLabel}
              onKeyDown={(e) => {
                if (e.key === "Enter") commitLabel();
                if (e.key === "Escape") {
                  setLabel(col.label);
                  setRename(false);
                }
              }}
              className="w-full rounded border border-amber-400 bg-white px-1 py-0.5 text-xs font-semibold text-slate-800 outline-none"
            />
          ) : (
            <button
              onClick={() => setRename(true)}
              title="Rename header"
              className="block w-full truncate text-left text-xs font-semibold text-slate-700 hover:text-slate-900"
            >
              {col.label}
            </button>
          )}
          <div className="mt-0.5 flex items-center gap-1">
            {col.reconcileRole && (
              <span
                className={`h-1.5 w-1.5 rounded-full ${ROLE_COLOR[col.reconcileRole] ?? "bg-slate-400"}`}
                title={`Cross-check role: ${col.reconcileRole}`}
              />
            )}
            <span className="text-[9px] uppercase tracking-wide text-slate-400">
              {col.type}
            </span>
          </div>
        </div>
        <button
          onClick={() => setMenu((m) => !m)}
          className="rounded p-0.5 text-slate-400 opacity-0 hover:bg-slate-200 hover:text-slate-700 group-hover:opacity-100"
        >
          <Menu width={14} />
        </button>
      </div>

      {menu && (
        <div
          ref={menuRef}
          className="absolute right-2 top-9 z-50 w-60 rounded-xl border border-slate-200 bg-white p-3 shadow-xl"
        >
          <div className="mb-1 text-[10px] font-semibold uppercase tracking-wide text-slate-400">
            Column type
          </div>
          <div className="mb-3 grid grid-cols-3 gap-1">
            {COLUMN_TYPES.map((t) => (
              <button
                key={t.value}
                onClick={() => onUpdate({ type: t.value })}
                className={`rounded-md border px-1 py-1 text-[11px] font-medium ${
                  col.type === t.value
                    ? "border-amber-500 bg-amber-50 text-amber-700"
                    : "border-slate-200 text-slate-600 hover:bg-slate-50"
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>

          {col.type === "select" && (
            <>
              <div className="mb-1 text-[10px] font-semibold uppercase tracking-wide text-slate-400">
                Dropdown options (comma separated)
              </div>
              <textarea
                value={optionsDraft}
                onChange={(e) => setOptionsDraft(e.target.value)}
                onBlur={() =>
                  onUpdate({
                    options: optionsDraft
                      .split(",")
                      .map((s) => s.trim())
                      .filter(Boolean),
                  })
                }
                rows={2}
                className="mb-3 w-full resize-none rounded-md border border-slate-200 px-2 py-1 text-xs outline-none focus:border-amber-400"
                placeholder="Option A, Option B"
              />
            </>
          )}

          <div className="mb-1 text-[10px] font-semibold uppercase tracking-wide text-slate-400">
            Cross-check role
          </div>
          <select
            value={col.reconcileRole ?? ""}
            onChange={(e) => onUpdate({ reconcileRole: (e.target.value || null) as Column["reconcileRole"] })}
            className="mb-3 w-full rounded-md border border-slate-200 px-2 py-1 text-xs outline-none focus:border-amber-400"
          >
            <option value="">None</option>
            {RECONCILE_ROLES[sheetType].map((r) => (
              <option key={r.value} value={r.value}>
                {r.label}
              </option>
            ))}
          </select>

          <div className="flex items-center justify-between">
            <div className="flex gap-1">
              <button
                disabled={index === 0}
                onClick={() => onMove(-1)}
                className="rounded-md border border-slate-200 p-1 text-slate-600 hover:bg-slate-50 disabled:opacity-30"
                title="Move left"
              >
                <ChevronLeft width={14} />
              </button>
              <button
                disabled={index === count - 1}
                onClick={() => onMove(1)}
                className="rounded-md border border-slate-200 p-1 text-slate-600 hover:bg-slate-50 disabled:opacity-30"
                title="Move right"
              >
                <ChevronRight width={14} />
              </button>
            </div>
            <button
              onClick={() => {
                setMenu(false);
                onDelete();
              }}
              className="inline-flex items-center gap-1 rounded-md bg-red-50 px-2 py-1 text-xs font-medium text-red-600 hover:bg-red-100"
            >
              <Trash width={12} /> Delete
            </button>
          </div>
        </div>
      )}
    </th>
  );
}
