"use client";

import { useCallback, useState } from "react";
import { useRouter } from "next/navigation";
import type { Column, Project, Sheet } from "@/lib/types";
import { computeReconciliation, formatCurrency } from "@/lib/finance";
import Spreadsheet from "./Spreadsheet";
import Reconciliation from "./Reconciliation";
import {
  ArrowLeft,
  Building,
  Calendar,
  Check,
  Download,
  Pencil,
  Scale,
  Wallet,
  X,
} from "./Icons";

type Tab = "expense" | "cost" | "reconcile";

export default function Workspace({ initial }: { initial: Project }) {
  const router = useRouter();
  const [project, setProject] = useState<Project>(initial);
  const [tab, setTab] = useState<Tab>("expense");
  const [editing, setEditing] = useState(false);

  const base = `/api/projects/${project.id}`;
  const post = (path: string, body: unknown) =>
    fetch(base + path, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
  const put = (path: string, body: unknown) =>
    fetch(base + path, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
  const patch = (path: string, body: unknown) =>
    fetch(base + path, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
  const del = (path: string) => fetch(base + path, { method: "DELETE" });

  const mapSheet = (s: Sheet, fn: (s: Sheet) => Sheet): Sheet[] =>
    project.sheets.map((x) => (x.id === s.id ? fn(x) : x));

  const changeCell = useCallback(
    (sheetId: number, rowId: number, columnId: number, value: string) => {
      setProject((prev) => ({
        ...prev,
        sheets: prev.sheets.map((s) =>
          s.id !== sheetId
            ? s
            : {
                ...s,
                rows: s.rows.map((r) =>
                  r.id === rowId
                    ? { ...r, cells: { ...r.cells, [columnId]: value } }
                    : r,
                ),
              },
        ),
      }));
      put("/cells", { rowId, columnId, value }).catch(() => {});
    },
    [base],
  );

  const addRow = (sheetId: number) => {
    const tempId = -Math.floor(Math.random() * 1e9);
    setProject((prev) => ({
      ...prev,
      sheets: prev.sheets.map((s) =>
        s.id !== sheetId
          ? s
          : { ...s, rows: [...s.rows, { id: tempId, position: s.rows.length, cells: {} }] },
      ),
    }));
    post("/rows", { sheetId })
      .then((res) => res.json())
      .then((data: { id: number }) =>
        setProject((prev) => ({
          ...prev,
          sheets: prev.sheets.map((s) =>
            s.id !== sheetId
              ? s
              : {
                  ...s,
                  rows: s.rows.map((r) => (r.id === tempId ? { ...r, id: data.id } : r)),
                },
          ),
        })),
      );
  };

  const deleteRow = (sheetId: number, rowId: number) => {
    setProject((prev) => ({
      ...prev,
      sheets: prev.sheets.map((s) =>
        s.id !== sheetId ? s : { ...s, rows: s.rows.filter((r) => r.id !== rowId) },
      ),
    }));
    del(`/rows/${rowId}`).catch(() => {});
  };

  const addColumn = (sheetId: number) => {
    const tempId = -Math.floor(Math.random() * 1e9);
    setProject((prev) => ({
      ...prev,
      sheets: prev.sheets.map((s) =>
        s.id !== sheetId
          ? s
          : {
              ...s,
              columns: [
                ...s.columns,
                {
                  id: tempId,
                  sheetId,
                  label: "New Column",
                  type: "text",
                  options: null,
                  reconcileRole: null,
                  width: 180,
                  position: s.columns.length,
                },
              ],
            },
      ),
    }));
    post("/columns", { sheetId, label: "New Column", type: "text" })
      .then((res) => res.json())
      .then((data: Column) =>
        setProject((prev) => ({
          ...prev,
          sheets: prev.sheets.map((s) =>
            s.id !== sheetId
              ? s
              : {
                  ...s,
                  columns: s.columns.map((c) =>
                    c.id === tempId ? { ...data, sheetId } : c,
                  ),
                },
          ),
        })),
      );
  };

  const updateColumn = (sheetId: number, colId: number, p: Partial<Column>) => {
    setProject((prev) => ({
      ...prev,
      sheets: prev.sheets.map((s) =>
        s.id !== sheetId
          ? s
          : {
              ...s,
              columns: s.columns.map((c) => (c.id === colId ? { ...c, ...p } : c)),
            },
      ),
    }));
    // role exclusivity handled server-side
    patch(`/columns/${colId}`, p).catch(() => {});
  };

  const deleteColumn = (sheetId: number, colId: number) => {
    setProject((prev) => ({
      ...prev,
      sheets: prev.sheets.map((s) =>
        s.id !== sheetId
          ? s
          : { ...s, columns: s.columns.filter((c) => c.id !== colId) },
      ),
    }));
    del(`/columns/${colId}`).catch(() => {});
  };

  const moveColumn = (sheetId: number, colId: number, dir: -1 | 1) => {
    const sheet = project.sheets.find((s) => s.id === sheetId);
    if (!sheet) return;
    const arr = [...sheet.columns];
    const i = arr.findIndex((c) => c.id === colId);
    const j = i + dir;
    if (i < 0 || j < 0 || j >= arr.length) return;
    [arr[i], arr[j]] = [arr[j], arr[i]];
    const reindexed = arr.map((c, k) => ({ ...c, position: k }));
    setProject((prev) => ({
      ...prev,
      sheets: prev.sheets.map((s) => (s.id === sheetId ? { ...s, columns: reindexed } : s)),
    }));
    patch(`/columns/${colId}`, { position: reindexed[i].position }).catch(() => {});
    patch(`/columns/${arr[j].id}`, { position: reindexed[j].position }).catch(() => {});
  };

  const saveProject = (p: Partial<Project>) => {
    setProject((prev) => ({ ...prev, ...p }));
    patch("", p).catch(() => {});
  };

  const exportCsv = (sheet: Sheet) => {
    const header = sheet.columns.map((c) => `"${c.label.replace(/"/g, '""')}"`).join(",");
    const lines = sheet.rows.map((r) =>
      sheet.columns
        .map((c) => `"${(r.cells[c.id] ?? "").replace(/"/g, '""')}"`)
        .join(","),
    );
    const totals = sheet.columns
      .map((c) =>
        c.type === "currency" || c.type === "number"
          ? String(
              sheet.rows.reduce((a, r) => a + (parseFloat(r.cells[c.id] ?? "0") || 0), 0),
            )
          : "",
      )
      .join(",");
    const csv = [header, ...lines, `"TOTAL",${totals}`].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${project.name.replace(/\s+/g, "_")}_${sheet.type}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const expenseSheet = project.sheets.find((s) => s.type === "expense");
  const costSheet = project.sheets.find((s) => s.type === "cost_control");
  const activeSheet =
    tab === "expense" ? expenseSheet : tab === "cost" ? costSheet : undefined;
  const rec = computeReconciliation(project);

  const tabs: { key: Tab; label: string; icon: React.ReactNode }[] = [
    { key: "expense", label: "Balance & Expenses", icon: <Wallet width={15} /> },
    { key: "cost", label: "Cost Control & Payments", icon: <Building width={15} /> },
    { key: "reconcile", label: "Cross-Check", icon: <Scale width={15} /> },
  ];

  return (
    <div className="min-h-screen bg-slate-100">
      {/* Top bar */}
      <header className="sticky top-0 z-40 border-b border-slate-200 bg-white">
        <div className="mx-auto flex max-w-[1400px] items-center gap-3 px-5 py-3">
          <button
            onClick={() => router.push("/")}
            className="inline-flex items-center gap-1 rounded-lg px-2 py-1 text-sm text-slate-500 hover:bg-slate-100"
          >
            <ArrowLeft width={16} /> Projects
          </button>
          <div className="h-5 w-px bg-slate-200" />
          <Building width={18} className="text-amber-600" />
          <span className="font-bold text-slate-900">BuildLedger</span>
          <span className="ml-auto hidden items-center gap-2 text-xs text-slate-500 md:flex">
            <span
              className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 font-medium ${
                rec.balanced
                  ? "bg-emerald-100 text-emerald-700"
                  : "bg-rose-100 text-rose-700"
              }`}
            >
              {rec.balanced ? <Check width={12} /> : <X width={12} />}
              {rec.balanced ? "Balanced" : "Out of balance"}
            </span>
          </span>
        </div>
      </header>

      <main className="mx-auto max-w-[1400px] px-5 py-6">
        {/* Project header */}
        {editing ? (
          <ProjectEditor
            project={project}
            onSave={(p) => {
              saveProject(p);
              setEditing(false);
            }}
            onCancel={() => setEditing(false)}
          />
        ) : (
          <div className="mb-5 flex flex-wrap items-end justify-between gap-4">
            <div>
              <h1 className="text-2xl font-bold text-slate-900">{project.name}</h1>
              <div className="mt-1 flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-slate-500">
                {project.client && <span>👤 {project.client}</span>}
                {project.location && <span>📍 {project.location}</span>}
                {project.startDate && (
                  <span className="inline-flex items-center gap-1">
                    <Calendar width={13} /> {project.startDate}
                  </span>
                )}
                <span className="rounded-full bg-slate-200 px-2 py-0.5 text-xs font-medium text-slate-600">
                  {project.status}
                </span>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="text-right">
                <div className="text-xs uppercase tracking-wide text-slate-400">
                  Contract budget
                </div>
                <div className="text-lg font-bold text-slate-800">
                  {formatCurrency(parseFloat(project.budget ?? "0"))}
                </div>
              </div>
              <button
                onClick={() => setEditing(true)}
                className="inline-flex items-center gap-1 rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
              >
                <Pencil width={14} /> Edit
              </button>
            </div>
          </div>
        )}

        {/* Tabs */}
        <div className="mb-4 flex flex-wrap items-center gap-1 border-b border-slate-200">
          {tabs.map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`inline-flex items-center gap-2 border-b-2 px-4 py-2.5 text-sm font-medium transition-colors ${
                tab === t.key
                  ? "border-amber-500 text-slate-900"
                  : "border-transparent text-slate-500 hover:text-slate-800"
              }`}
            >
              {t.icon}
              {t.label}
              {t.key === "reconcile" && !rec.balanced && (
                <span className="h-2 w-2 rounded-full bg-rose-500" />
              )}
            </button>
          ))}
        </div>

        {/* Content */}
        {tab === "reconcile" ? (
          <Reconciliation project={project} />
        ) : activeSheet ? (
          <div className="flex h-[calc(100vh-280px)] min-h-[460px] flex-col overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div className="flex items-center justify-end gap-2 border-b border-slate-100 bg-white px-4 py-2">
              <button
                onClick={() => exportCsv(activeSheet)}
                className="inline-flex items-center gap-1 rounded-lg border border-slate-300 px-3 py-1.5 text-sm text-slate-600 hover:bg-slate-50"
              >
                <Download width={14} /> Export CSV
              </button>
            </div>
            <div className="flex-1 overflow-hidden">
              <Spreadsheet
                key={activeSheet.id}
                sheet={activeSheet}
                onChangeCell={(rowId, columnId, value) =>
                  changeCell(activeSheet.id, rowId, columnId, value)
                }
                onAddRow={() => addRow(activeSheet.id)}
                onDeleteRow={(rowId) => deleteRow(activeSheet.id, rowId)}
                onAddColumn={() => addColumn(activeSheet.id)}
                onUpdateColumn={(colId, p) => updateColumn(activeSheet.id, colId, p)}
                onDeleteColumn={(colId) => deleteColumn(activeSheet.id, colId)}
                onMoveColumn={(colId, dir) => moveColumn(activeSheet.id, colId, dir)}
              />
            </div>
          </div>
        ) : null}
      </main>
    </div>
  );
}

function ProjectEditor({
  project,
  onSave,
  onCancel,
}: {
  project: Project;
  onSave: (p: Partial<Project>) => void;
  onCancel: () => void;
}) {
  const [form, setForm] = useState({
    name: project.name,
    client: project.client ?? "",
    location: project.location ?? "",
    budget: project.budget ?? "",
    startDate: project.startDate ?? "",
    status: project.status,
  });
  const field =
    "w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none focus:border-amber-400";

  return (
    <div className="mb-5 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
      <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
        <div className="md:col-span-3">
          <label className="text-xs font-medium text-slate-500">Project name</label>
          <input className={field} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
        </div>
        <div>
          <label className="text-xs font-medium text-slate-500">Client</label>
          <input className={field} value={form.client} onChange={(e) => setForm({ ...form, client: e.target.value })} />
        </div>
        <div>
          <label className="text-xs font-medium text-slate-500">Location</label>
          <input className={field} value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} />
        </div>
        <div>
          <label className="text-xs font-medium text-slate-500">Status</label>
          <select className={field} value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })}>
            {["Active", "On Hold", "Completed", "Tendering"].map((s) => (
              <option key={s}>{s}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="text-xs font-medium text-slate-500">Contract budget (AUD)</label>
          <input className={field} value={form.budget} onChange={(e) => setForm({ ...form, budget: e.target.value })} inputMode="decimal" />
        </div>
        <div>
          <label className="text-xs font-medium text-slate-500">Start date</label>
          <input type="date" className={field} value={form.startDate} onChange={(e) => setForm({ ...form, startDate: e.target.value })} />
        </div>
      </div>
      <div className="mt-4 flex justify-end gap-2">
        <button onClick={onCancel} className="rounded-lg border border-slate-300 px-4 py-2 text-sm text-slate-600 hover:bg-slate-50">
          Cancel
        </button>
        <button
          onClick={() => onSave(form)}
          className="rounded-lg bg-slate-900 px-4 py-2 text-sm font-medium text-white hover:bg-slate-800"
        >
          Save changes
        </button>
      </div>
    </div>
  );
}
